/**
 * Created by Angel Quispe
 */
const loginService = require('./../services/loginService');
const userService = require('./../services/userService');
const recaptchaService = require('../services/recaptchaService');
const utils = require('./../common/utils');
const errors = require('./../common/errors');

const login = async (req, res, next) => {

    const {docType, doc, password, recaptcha, cargo, position} = req.body;

    if (utils.isEmpty(docType) ||
        utils.isEmpty(doc) ||
        utils.isEmpty(password) ||
        utils.isEmpty(recaptcha)) {
        return res.sendStatus(400);
    }

    //Para el caso de empresas
    if ( docType === 'ruc' ||  docType === 'pr' && utils.isEmpty(position)){
        return res.sendStatus(400);
    }

    if (process.env.DISABLED_RECAPTCHA === 'false' && !await recaptchaService.isValid(recaptcha, req.ip)) {
        return res.sendStatus(400);
    }

    const result = await loginService.login(docType, doc, password, cargo);

    if (!result.jwtToken) {
        return res.json({success: false, error: result.error});
    }

    let response = {success: true, token: result.jwtToken, updated_password: result.updated_password};
    return res.json(response);
}

const logout = async (req, res, next) => {
    let authHeader = req.headers['authorization'];
    if (!authHeader) {
        return res.sendStatus(401);
    }
    await loginService.logout(authHeader)

    return res.json({success: true});
}

const recoverPassword = async (req, res, next) => {
    const {docType, doc, cargo, recaptcha} = req.body;

    if (utils.isEmpty(docType) || utils.isEmpty(doc) || utils.isEmpty(recaptcha)) {
        return res.sendStatus(400);
    }
    
    if (process.env.DISABLED_RECAPTCHA === 'false' && !await recaptchaService.isValid(recaptcha, req.ip)) {
        return res.sendStatus(401);
    }

    const result = await userService.recoverPassword(docType, doc, cargo);

    return res.json(result);
}

const validChangePassword = async (req, res, next) => {
    const {doc, id} = req.params;

    if (utils.isEmpty(doc) || utils.isEmpty(id)) {
        return res.sendStatus(400);
    }

    const result = await userService.validChangePassword(doc, id);

    return res.json(result);
}

const newPassword = async (req, res, next) => {
    const {oldPassword, newPassword, repeatNewPassword} = req.body;

    if (utils.isEmpty(oldPassword) || utils.isEmpty(newPassword) || utils.isEmpty(repeatNewPassword)) {
        return res.sendStatus(400);
    }

    if (newPassword !== repeatNewPassword) {
        return res.sendStatus(400);
    }

    if (!utils.validNewPassword(newPassword)) {
        return res.json({success: false, error: errors.NEW_PASSWORD_REGEX});
    }

    const result = await userService.updatePassword(req.user.docType, req.user.doc, req.user.profile, oldPassword, newPassword, req.user.id);

    if (!result.success) {
        return res.json({success: false, error: result.error});
    }

    return res.json({success: true});
}

module.exports = {login, newPassword, recoverPassword, validChangePassword,logout};

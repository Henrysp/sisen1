/**
 * Created by Miguel Pazo (https://miguelpazo.com)
 */

const expect = require('chai').expect;
const loginService = require('./../services/loginService');

describe('loginServiceTest', () => {

    it('loginTest()', async () => {
        console.log('ok')
    });
});

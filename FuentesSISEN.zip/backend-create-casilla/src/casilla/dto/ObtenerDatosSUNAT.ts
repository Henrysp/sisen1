export class responseSunat{

    success : boolean;
    razonSocial !: string;


}
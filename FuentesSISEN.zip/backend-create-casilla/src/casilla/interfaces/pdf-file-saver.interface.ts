export interface PdfFileSaverInterface {
  savePdf(): Promise<void>;
}

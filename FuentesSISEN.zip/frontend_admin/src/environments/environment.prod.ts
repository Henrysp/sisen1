export const environment = {
  production: true,
  baseUrl: '',
  KeycodeCaptcha: '6LfdFYQqAAAAAJ6H5G9Np-t3QMXEagvunzVqlcfR',
  SECRET_KEY: '5iseN-$2022',
};
// Key anterior 22/11/2024
// KeycodeCaptcha: '6Ld8Z2oeAAAAAKR8fzQCyiSt-sItVnEi2D-xJBie',


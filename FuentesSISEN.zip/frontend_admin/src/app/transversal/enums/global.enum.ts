export enum Profile {
    RegistryOperator = 'register',
    Notifier         = 'notifier',
    Administrador         = 'admin',
    Evaluator = 'evaluator',
    QueryOperator = 'consult'

}

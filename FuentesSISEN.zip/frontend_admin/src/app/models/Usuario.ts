export class Usuario {
  nombres: string;
  apellidos: string;
  rol: string;
  
 
  constructor() {
  }
}



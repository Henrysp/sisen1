export class Departamento {
    ubdep = '';
    nodep = '';
  }
export class Provincia {
    ubdep = '';
    ubprv = '';
    noprv = '';
}
export class Distrito {
    ubdep = '';
    ubprv = '';
    ubdis = '';
    nodis = '';
}

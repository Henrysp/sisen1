export class Cargo {
  codigo: string = "";
  nombre: string = "";
}

export class NotificationData {
    success     : boolean;
	page        : number;
	count       : number;
	recordsTotal: number;
	Items       : Notification[];
}

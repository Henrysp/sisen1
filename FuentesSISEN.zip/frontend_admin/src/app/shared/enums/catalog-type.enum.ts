export enum CatalogType{
    JOB_AREA='job_area',
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-boxes',
  templateUrl: './list-boxes.component.html',
  styleUrls: ['./list-boxes.component.scss']
})
export class ListBoxesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pop-filtro',
  templateUrl: './pop-filtro.component.html',
  styleUrls: ['./pop-filtro.component.scss']
})
export class PopFiltroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

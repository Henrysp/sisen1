import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operador',
  templateUrl: './operador.component.html',
  styleUrls: ['./operador.component.scss']
})
export class OperadorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

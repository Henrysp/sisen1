import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verificacion-navegador',
  templateUrl: './verificacion-navegador.component.html',
  styleUrls: ['./verificacion-navegador.component.css']
})
export class VerificacionNavegadorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class Departamento {
  ubdep: string = ""
  nodep: string = ""
}

export class Provincia {
  ubdep: string = ""
  ubprv: string = ""
  noprv: string = ""
}

export class Distrito {
  ubdep: string = ""
  ubprv: string = ""
  ubdis: string = ""
  nodis: string = ""
}

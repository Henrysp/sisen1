export interface ElectoralProcessDTO {
    _id: string;
    name: string;
    status: number;
    shortName: string;
    year: number;
    election_date: Date;
}

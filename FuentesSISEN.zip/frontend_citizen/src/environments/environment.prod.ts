export const environment = {
  production: true,
  baseUrl: '',
  SECRET_KEY_CITIZEN: '5iseN-$2022-Cit1z3n',
  KeycodeCaptcha: '6Ld8Z2oeAAAAAKR8fzQCyiSt-sItVnEi2D-xJBie',
};

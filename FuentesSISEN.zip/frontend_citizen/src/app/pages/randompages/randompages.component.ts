import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-randompages',
  templateUrl: './randompages.component.html',
  styleUrls: ['./randompages.component.scss']
})
export class RandompagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  value = 'Clear me';

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notificacion-adjuntos',
  templateUrl: './notificacion-adjuntos.component.html',
  styleUrls: ['./notificacion-adjuntos.component.scss']
})
export class NotificacionAdjuntosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

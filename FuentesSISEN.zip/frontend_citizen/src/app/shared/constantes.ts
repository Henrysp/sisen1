export const TOKEN_NAME = 'token';

export const MAXINTENT = 3;

export const ERROR_SERVER = 'El servicio no esta disponible, inténtelo de nuevo o más tarde';

export const VERSION_SISEN = 'SISEN v2.0.0';
